package com.Kiranacademy.InfrastructureStatistic;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.InfrastructureRoad.Road;

@RestController
public class InfrastructureController1 {

@PostMapping("bridgescount")
 int noOfBridgesInIndia(){
	return 7856;
}

@PostMapping("addbridgeinfo")
public void addbridge(@RequestBody Road bridge) {
	System.out.println(bridge);
}



@GetMapping("bridgeinfo")
Road fetchBridgeInfo() {
	Road bridge = new Road("omerga",45,"800 mtr","89 mtr");
	return bridge;
	
}



@RequestMapping("bridgesinfo")
ArrayList<Road>fetchBridgesInfo() {
ArrayList<Road> alBridgeList = new ArrayList<Road>();
	
	Road bridge =new Road("pune" ,11,"500 mtr ","50 mtr");
    Road bridge1 =new Road("pune" ,13,"50 mtr ","50 mtr");
	Road bridge2=new Road("pune" ,15,"600 mtr ","50 mtr");
	Road bridge3=new Road("pune" ,16,"800 mtr ","50 mtr");
	Road bridge4=new Road("pune" ,17,"700 mtr ","50 mtr");
	
	alBridgeList.add(bridge);
	alBridgeList.add(bridge1);
	alBridgeList.add(bridge2);
	alBridgeList.add(bridge3);
	alBridgeList.add(bridge4);
	
	return alBridgeList;
	
	

}
@RequestMapping("bridgesnamesbycity/{Cityname}/{villagename}")

ArrayList<String> nameOfBridgesInIndia(@PathVariable String Cityname,@PathVariable String villagename){
	ArrayList<String>listBridges =new ArrayList<String>();

	System.out.println(" i am in nameOfBridgesincity>>" +Cityname);
	System.out.println(" i am in nameOfBridgesincity>>" +villagename);
	

	if(Cityname.equals("pune")) {
		listBridges.add("rajaram bridge");
		listBridges.add("z bridge");
		listBridges.add("navle bridge");
		listBridges.add("warje bridge");
		listBridges.add("dandeker bridge");
	}else {
		
	listBridges.add("rajaram bridge");
	listBridges.add("z bridge");
	listBridges.add("navle bridge");
	listBridges.add("warje bridge");
	listBridges.add("dandeker bridge");
	}
	return listBridges;
	

	
}



}
