package com.Kiranacademy.InfrastructureStatistic;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InstrastructureController {
	
	@RequestMapping("bridgesCount")
	int noOfBridgesinIndia() {
		return 7856;
	}
	@RequestMapping("bridgesnamebyCity")
	ArrayList<String>nameOfBridgesinCity() {
		
		ArrayList<String> listBridges = new ArrayList<String>();
		listBridges.add("rajaram bridge");
		listBridges.add(" z bridge");
		listBridges.add("navle bridge");
		listBridges.add("warje bridge");
		listBridges.add("dandekar bridge");

	return listBridges ;
	}
}
	


