package com.priyankaAcademy;

public class InfrastructureDao {

}
