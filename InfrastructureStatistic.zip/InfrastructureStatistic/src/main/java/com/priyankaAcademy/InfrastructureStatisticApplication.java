package com.priyankaAcademy;

public class InfrastructureStatisticApplication {

}
