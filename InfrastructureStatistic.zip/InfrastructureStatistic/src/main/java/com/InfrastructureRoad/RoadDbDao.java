package com.InfrastructureRoad;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.Statement;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RoadDbDao {

@GetMapping("getRoaddata")


static ArrayList<Road> dataDo() throws Exception{
	

Class.forName("com.mysql.cj.jdbc.Driver");

Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bridge1","root","root");

String sql ="select * from bridge1";

Statement statment = connection.createStatement();

ResultSet ResultSet =statment.executeQuery(sql);

ArrayList<Road> alroad=new ArrayList<Road>();

while(ResultSet.next()) {
	String bridgCity=ResultSet.getString(1);
	int bridgeNumber=ResultSet.getInt(2);
	String bridgeLength=ResultSet.getString(3);
	String bridgewidth=ResultSet.getString(4);
	Road road = new Road(bridgCity,bridgeNumber,bridgeLength,bridgewidth);
    alroad.add(road);
	System.out.println("bridgCity >>"+bridgCity);
	System.out.println("bridgeNumber >>"+bridgeNumber);
	System.out.println("bridgeLength>>"+bridgeLength);
	System.out.println("bridgewidth>>"+bridgewidth);

}
return alroad;
}
}

