package com.InfrastructureRoad;

public class Road {
	String  bridgeCity;
	int bridgeNumber;
    String  bridgeLength;
	String bridgewidth;
	Road(){
		
	}
	public Road(String bridgCity, int bridgeNumber, String bridgeLength, String bridgewidth) {
		super();
		this.bridgeCity = bridgCity;
		this.bridgeNumber = bridgeNumber;
		this.bridgeLength = bridgeLength;
		this.bridgewidth = bridgewidth;
	}
	
	
	public String getBridgCity() {
		return bridgeCity;
	}

	
	public void setBridgCity(String bridgCity) {
		this.bridgeCity = bridgCity;
	}

	
	public int getBridgeNumber() {
		return bridgeNumber;
	}

	public void setBridgeNumber(int bridgeNumber) {
		this.bridgeNumber = bridgeNumber;
	}

	
	public String getBridgeLength() {
		return bridgeLength;
	}

	public void setBridgeLength(String bridgeLength) {
		this.bridgeLength = bridgeLength;
	}

	
	public String getBridgewidth() {
		return bridgewidth;
	}

	public void setBridgewidth(String bridgewidth) {
		this.bridgewidth = bridgewidth;
	}


	@Override
	public String toString() {
		return "Bridge [bridgCity=" + bridgeCity + ", bridgeNumber=" + bridgeNumber + ", bridgeLength=" + bridgeLength
				+ ", bridgewidth=" + bridgewidth + "]";
	}

	
}
