package com.InfrastructureRoad;

import java.util.ArrayList;

public class RoadDbservice {
	public static void main(String[] args) throws Exception {
		
		  ArrayList<Road> al = RoadDbDao.dataDo();
		    for(Road road: al) {
		    	System.out.println(road.bridgeCity);
		    	System.out.println(road.bridgeNumber);
		    	System.out.println(road.bridgeLength);
		    	System.out.println(road.bridgewidth);
		    }
	}
}
		    



