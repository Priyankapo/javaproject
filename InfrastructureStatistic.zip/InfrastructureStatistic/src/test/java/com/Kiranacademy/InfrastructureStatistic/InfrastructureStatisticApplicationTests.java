package com.Kiranacademy.InfrastructureStatistic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfrastructureStatisticApplicationTests {

	@Test
	void contextLoads() {
	}

}
